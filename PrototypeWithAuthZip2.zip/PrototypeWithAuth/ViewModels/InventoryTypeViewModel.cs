﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PrototypeWithAuth.Models;


namespace PrototypeWithAuth.ViewModels
{
    public class InventoryTypeViewModel
    {
        public ProductSubcategory ProductSubcategories { get; set; }
        public Product Products { get; set; }

    }
}
